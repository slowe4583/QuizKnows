<?php
require "header.php";
?>
<html>
<link rel="stylesheet" href="style.css">

    <h1>Create A Set</h1>
    <body>
        Set Name:<input type="text" id=setName>
        
        <br>
        <br>
        <a href="createCard.php">
        <button>Add a Flashcard?</button>
        </a>
    </body>
</html>