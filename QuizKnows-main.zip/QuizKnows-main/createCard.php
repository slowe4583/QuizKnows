<html>
<link rel="stylesheet" href="style.css">

    <h1>Create A Card</h1>
    <body>
        Question:<input type="text" id=setQuestion>
        Answer:<input type="text" id=setAnswer>
        <br>
        <br>

        <a href="mySets.php">
        <button>Done</button>
        </a>
       
        <br>
        <br>

        <a href="mySets.php">
        <button>Go Back</button>
        </a>
    </body>
</html>