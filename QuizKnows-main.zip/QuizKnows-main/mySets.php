<?php
require "header.php";
?>
<!DOCTYPE html>
<html lang="en">
<meta charset="UTF-8">
<title>Page Title</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="stylesheet" href="style.css">
    <h1>My Sets</h1>
    <body>
        <a href="createSet.php">
        <button  >Create New Set</button>
        </a>
    </body>